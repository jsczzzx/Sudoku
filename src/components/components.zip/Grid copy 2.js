import React, { useState, useEffect, useRef, createRef, setState, useContext, createContext,AsyncStorage } from "react"
import { Text, TextInput, View, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, TouchableHighlight } from 'react-native';
import Button from './Button';
import {withTheme} from 'react-native-paper'
import RoundButton from './RoundButton';
import {Stopwatch} from 'react-native-stopwatch-timer';


const Grid = ({theme, vals, userName, mode}) => {

  const [currentTime, setCurrentTime] = useState(0);


  const StopWatch= () => {
    const [isStopwatchStart, setIsStopwatchStart] = useState(true);
    const [resetStopwatch, setResetStopwatch] = useState(false);
    const [time, setTime] = useState();
    return (
  
      <View style={styles.sectionStyle}>
        <Stopwatch
          laps
          msecs
          start={isStopwatchStart}
          //To start
          reset={resetStopwatch}
          //To reset
          options={options}
          //options for the styling
          getTime={(time) => {
            setTime(time);
          }}
        />
        <RoundButton type='play-circle-outline'
          onPress = {()=>{
            setIsStopwatchStart(!isStopwatchStart);
            //setResetStopwatch(false);
            //setCurrentTime(time);
          }}
        />
      </View>
          
    );
  };

  
  const LargeGrid = () => {
    return (
      <View style={{alignItems: 'center'}}>
        <StopWatch/>

      <Button mode="contained" onPress={()=>{setCurrentTime(currentTime+1)}}>
        {currentTime}
      </Button>
      </View>
    )
  }
  return (
    <LargeGrid/>
  );
}

export default withTheme(Grid);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-around'
  },
  timerPart: {
    flex: 1.5,
    alignItems: 'center',
    justifyContent: 'flex-start',
    padding: 10
  },
  mainPart: {
    flex: 5,
    alignItems: 'center',
    justifyContent: 'space-around'
  },
  subPart: {
    flex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around'
  },
  subPart1: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  subPart2: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  largeGrid:{
    borderWidth: 3
  },
  gridRow:{
    flexDirection: 'row'
  },
  smallGrid:{
    borderWidth: 1.5
  },
  Row: {
    flexDirection: 'row',
    backgroundColor: 'white',
    justifyContent: 'center',
  },
  CellBlue:{
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#EAF2F8',
    margin: 2,
    height: 30,
    width: 30,
  },
  CellBlueSelected:{
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#EAF2F8',
    margin: 2,
    borderWidth: 2,
    borderColor: 'red',
    height: 30,
    width: 30,
  },
  CellRed:{
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5B7B1',
    margin: 2,
    height: 30,
    width: 30,
  },
  CellRedSelected:{
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5B7B1',
    margin: 2,
    borderWidth: 2,
    borderColor: 'red',
    height: 30,
    width: 30,
  },
  sectionStyle: {
    flex: 1,
    flexDirection: 'row',
    marginTop: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

const options = {
  container: {
    backgroundColor: 'darkseagreen',
    padding: 5,
    borderRadius: 5,
    width: 200,
    alignItems: 'center',
  },
  text: {
    fontSize: 25,
    color: '#FFF',
    marginLeft: 7,
  },
};